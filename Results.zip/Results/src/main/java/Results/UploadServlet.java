package Results;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/uploadServlet")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 1,  // 1 MB
        maxFileSize = 1024 * 1024 * 10,      // 10 MB
        maxRequestSize = 1024 * 1024 * 50    // 50 MB
)
public class UploadServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "uploads";
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/result";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String applicationPath = request.getServletContext().getRealPath("");
        String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;

        File fileSaveDir = new File(uploadFilePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdirs();
        }

        for (Part part : request.getParts()) {
            String fileName = extractFileName(part);
            String sanitizedTableName = sanitizeTableName(fileName);
            System.out.println("Sanitized Table Name: " + sanitizedTableName);
            File file = new File(uploadFilePath + File.separator + fileName);
            part.write(file.getAbsolutePath());

            try {
                createTableFromFile(sanitizedTableName, file);
                importDataIntoDatabase(sanitizedTableName, file);
                response.getWriter().println("File uploaded and data imported successfully!");
            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().println("File uploaded but failed to import data: " + e.getMessage());
                return;
            }
        }
    }

    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                String fileName = s.substring(s.indexOf("=") + 2, s.length() - 1);
                return fileName.replace(".csv", "");  // Remove the .csv extension
            }
        }
        return "";
    }

    private String sanitizeTableName(String tableName) {
        return tableName.replaceAll("[^a-zA-Z0-9_]", "_");
    }

    private void createTableFromFile(String tableName, File file) throws SQLException, IOException {
        Connection connection = null;
        Statement statement = null;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
            statement = connection.createStatement();

            String line = br.readLine();
            if (line != null) {
                String[] columns = line.split(",");
                StringBuilder createTableSQL = new StringBuilder("CREATE TABLE IF NOT EXISTS `" + tableName + "` (id INT AUTO_INCREMENT PRIMARY KEY, ");

                for (String column : columns) {
                    createTableSQL.append("`").append(column).append("` VARCHAR(255), ");
                }
                createTableSQL.setLength(createTableSQL.length() - 2); // Remove last comma and space
                createTableSQL.append(");");

                System.out.println("Executing SQL: " + createTableSQL.toString());
                statement.executeUpdate(createTableSQL.toString());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new SQLException("Failed to create table: " + e.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void importDataIntoDatabase(String tableName, File file) throws SQLException, IOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);

            String line = br.readLine(); // Skip header line
            if (line != null) {
                String[] columns = line.split(",");
                StringBuilder sql = new StringBuilder("INSERT INTO `" + tableName + "` (");

                for (String column : columns) {
                    sql.append("`").append(column).append("`, ");
                }
                sql.setLength(sql.length() - 2); // Remove last comma and space
                sql.append(") VALUES (");
                sql.append("?,".repeat(columns.length));
                sql.setLength(sql.length() - 1); // Remove last comma
                sql.append(")");

                preparedStatement = connection.prepareStatement(sql.toString());

                while ((line = br.readLine()) != null) {
                    String[] values = line.split(",");
                    if (values.length != columns.length) {
                        System.out.println("Skipping line due to incorrect number of values: " + line);
                        continue;
                    }
                    for (int i = 0; i < values.length; i++) {
                        preparedStatement.setString(i + 1, values[i]);
                    }
                    preparedStatement.executeUpdate();
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new SQLException("Failed to import data into the database: " + e.getMessage());
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
